using System;

public class GlobalVariables
{
    public static Boolean muteConfig {get; set;}
    public static Boolean HSUpdated {get; set;}
}
